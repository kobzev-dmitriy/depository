package app;

public class AppConfig {

    //public static final String baseUrl = "http://192.168.58.122:8085";
    public static final String baseUrl = "http://192.168.58.196:9080";

    public static final String loginUser = "pda";

    public static final String passwordUser = "Deep2000";

    public static final String loginDefaultUser = "admin";

    public static final String passwordDefaultUser = "Deep2000";

}
